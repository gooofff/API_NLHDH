﻿namespace API
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnGetFolderInfo = new Button();
            txtFilePath = new TextBox();
            dataGridView1 = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            Column6 = new DataGridViewTextBoxColumn();
            Column7 = new DataGridViewTextBoxColumn();
            Column9 = new DataGridViewTextBoxColumn();
            Column8 = new DataGridViewTextBoxColumn();
            label1 = new Label();
            btnDeleteFile = new Button();
            txtXoa = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtSource = new TextBox();
            txtDes = new TextBox();
            btnCopy = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btnGetFolderInfo
            // 
            btnGetFolderInfo.Location = new Point(384, 45);
            btnGetFolderInfo.Name = "btnGetFolderInfo";
            btnGetFolderInfo.Size = new Size(75, 23);
            btnGetFolderInfo.TabIndex = 0;
            btnGetFolderInfo.Text = "Tra cứu";
            btnGetFolderInfo.UseVisualStyleBackColor = true;
            btnGetFolderInfo.Click += btnGetFolderInfo_Click;
            // 
            // txtFilePath
            // 
            txtFilePath.Location = new Point(195, 45);
            txtFilePath.Name = "txtFilePath";
            txtFilePath.Size = new Size(169, 23);
            txtFilePath.TabIndex = 1;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Column1, Column3, Column4, Column5, Column6, Column7, Column9, Column8 });
            dataGridView1.Location = new Point(43, 177);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(843, 272);
            dataGridView1.TabIndex = 2;
            // 
            // Column1
            // 
            Column1.HeaderText = "Tên tệp";
            Column1.Name = "Column1";
            // 
            // Column3
            // 
            Column3.HeaderText = "Kích thước";
            Column3.Name = "Column3";
            // 
            // Column4
            // 
            Column4.HeaderText = "Loại tệp";
            Column4.Name = "Column4";
            // 
            // Column5
            // 
            Column5.HeaderText = "Thời gian tạo";
            Column5.Name = "Column5";
            // 
            // Column6
            // 
            Column6.HeaderText = "Thời gian thay đổi gần nhất";
            Column6.Name = "Column6";
            // 
            // Column7
            // 
            Column7.HeaderText = "Thời gian truy cập gần nhất";
            Column7.Name = "Column7";
            // 
            // Column9
            // 
            Column9.HeaderText = "Chủ sở hữu";
            Column9.Name = "Column9";
            // 
            // Column8
            // 
            Column8.HeaderText = "Quyền truy cập";
            Column8.Name = "Column8";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(85, 49);
            label1.Name = "label1";
            label1.Size = new Size(86, 15);
            label1.TabIndex = 3;
            label1.Text = "Đường dẫn tệp";
            // 
            // btnDeleteFile
            // 
            btnDeleteFile.Location = new Point(384, 100);
            btnDeleteFile.Name = "btnDeleteFile";
            btnDeleteFile.Size = new Size(75, 24);
            btnDeleteFile.TabIndex = 4;
            btnDeleteFile.Text = "Xóa ";
            btnDeleteFile.UseVisualStyleBackColor = true;
            btnDeleteFile.Click += btnDeleteFile_Click_1;
            // 
            // txtXoa
            // 
            txtXoa.Location = new Point(195, 100);
            txtXoa.Name = "txtXoa";
            txtXoa.Size = new Size(169, 23);
            txtXoa.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(41, 103);
            label2.Name = "label2";
            label2.Size = new Size(130, 15);
            label2.TabIndex = 6;
            label2.Text = "Đường dẫn tệp cần xóa";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(525, 50);
            label3.Name = "label3";
            label3.Size = new Size(44, 15);
            label3.TabIndex = 7;
            label3.Text = "Nguồn";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(525, 105);
            label4.Name = "label4";
            label4.Size = new Size(31, 15);
            label4.TabIndex = 8;
            label4.Text = "Đích";
            // 
            // txtSource
            // 
            txtSource.Location = new Point(575, 47);
            txtSource.Name = "txtSource";
            txtSource.Size = new Size(169, 23);
            txtSource.TabIndex = 9;
            // 
            // txtDes
            // 
            txtDes.Location = new Point(575, 101);
            txtDes.Name = "txtDes";
            txtDes.Size = new Size(169, 23);
            txtDes.TabIndex = 10;
            // 
            // btnCopy
            // 
            btnCopy.Location = new Point(760, 66);
            btnCopy.Name = "btnCopy";
            btnCopy.Size = new Size(77, 39);
            btnCopy.TabIndex = 11;
            btnCopy.Text = "Sao chép";
            btnCopy.UseVisualStyleBackColor = true;
            btnCopy.Click += btnCopy_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(916, 461);
            Controls.Add(btnCopy);
            Controls.Add(txtDes);
            Controls.Add(txtSource);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtXoa);
            Controls.Add(btnDeleteFile);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Controls.Add(txtFilePath);
            Controls.Add(btnGetFolderInfo);
            Name = "Form1";
            Text = "Information";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnGetFolderInfo;
        private TextBox txtFilePath;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
        private DataGridViewTextBoxColumn Column7;
        private DataGridViewTextBoxColumn Column9;
        private DataGridViewTextBoxColumn Column8;
        private Label label1;
        private Button btnDeleteFile;
        private TextBox txtXoa;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtSource;
        private TextBox txtDes;
        private Button btnCopy;
    }
}