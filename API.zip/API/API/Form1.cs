﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Windows.Forms;

namespace API
{
    public partial class Form1 : Form
    {
        // Khai báo hàm API
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool GetFileInformationByHandle(IntPtr hFile, out BY_HANDLE_FILE_INFORMATION lpFileInformation);

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool DeleteFile(string lpFileName);

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern bool CopyFile(string lpExistingFileName, string lpNewFileName, bool bFailIfExists);


        // Khai báo struct chứa các thông tin về tệp mà hàm GetFileInformationByHandle sẽ trả về.
        [StructLayout(LayoutKind.Sequential)]
        private struct BY_HANDLE_FILE_INFORMATION
        {
            public uint FileAttributes;
            public System.Runtime.InteropServices.ComTypes.FILETIME CreationTime;
            public System.Runtime.InteropServices.ComTypes.FILETIME LastAccessTime;
            public System.Runtime.InteropServices.ComTypes.FILETIME LastWriteTime;
            public uint VolumeSerialNumber;
            public uint FileSizeHigh;
            public uint FileSizeLow;
            public uint NumberOfLinks;
            public uint FileIndexHigh;
            public uint FileIndexLow;
        }

        private bool DeleteFileUsingAPI(string DfilePath)
        {
            if (DeleteFile(DfilePath))
            {
                // Xóa thành công
                return true;
            }
            else
            {
                int error = Marshal.GetLastWin32Error();
                MessageBox.Show("Không thể xóa tệp, Mã lỗi: " + error);
                return false;
            }
        }
        public Form1()
        {
            InitializeComponent();
        }

        // Sự kiện nhấn nút đọc thông tin tệp và ghi lên datagridview
        private void btnGetFolderInfo_Click(object sender, EventArgs e)
        {
            // Đọc đường dẫn
            string filePath = txtFilePath.Text;
            if (File.Exists(filePath))
            {
                FileInfo fileInfo = new FileInfo(filePath);

                // Mở tệp dể lấy thông tin tệp
                using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    BY_HANDLE_FILE_INFORMATION fileInformation;
                    if (GetFileInformationByHandle(fs.SafeFileHandle.DangerousGetHandle(), out fileInformation))
                    {
                        // Tạo hàng mới trong datagridview
                        DataGridViewRow row = new DataGridViewRow();

                        // Tên tệp
                        row.Cells.Add(new DataGridViewTextBoxCell { Value = Path.GetFileNameWithoutExtension(filePath) });

                        // Kích thước
                        double sizeInKB = (double)(fileInformation.FileSizeHigh << 32 | fileInformation.FileSizeLow) / 1024;
                        row.Cells.Add(new DataGridViewTextBoxCell { Value = sizeInKB.ToString("F2") + " KB" });

                        // Lấy loại tệp (file extension)
                        string fileExtension = Path.GetExtension(filePath);
                        row.Cells.Add(new DataGridViewTextBoxCell { Value = fileExtension });

                        // Thời gian tạo
                        long fileTimeInt64 = ((long)fileInformation.CreationTime.dwHighDateTime << 32) + fileInformation.CreationTime.dwLowDateTime;
                        DateTime creationTime = DateTime.FromFileTime(fileTimeInt64);
                        row.Cells.Add(new DataGridViewTextBoxCell { Value = creationTime.ToString() });

                        // Chỉnh sửa cuối
                        long fileTimeInt641 = ((long)fileInformation.LastWriteTime.dwHighDateTime << 32) + fileInformation.LastWriteTime.dwLowDateTime;
                        DateTime LastWriteTime = DateTime.FromFileTime(fileTimeInt641);
                        row.Cells.Add(new DataGridViewTextBoxCell { Value = LastWriteTime.ToString() });

                        // Truy cập cuối
                        long fileTimeInt642 = ((long)fileInformation.LastAccessTime.dwHighDateTime << 32) + fileInformation.LastAccessTime.dwLowDateTime;
                        DateTime LastAccessTime = DateTime.FromFileTime(fileTimeInt642);
                        row.Cells.Add(new DataGridViewTextBoxCell { Value = LastAccessTime.ToString() });

                        // Lấy thông tin về quyền truy cập và quyền sở hữu
                        WindowsIdentity identity = WindowsIdentity.GetCurrent();
                        AuthorizationRuleCollection rules = fileInfo.GetAccessControl().GetAccessRules(true, true, typeof(NTAccount));
                        string owner = fileInfo.GetAccessControl().GetOwner(typeof(NTAccount)).ToString();
                        string accessRights = "";
                        foreach (FileSystemAccessRule rule in rules)
                        {
                            accessRights += rule.IdentityReference.Value + ": " + rule.FileSystemRights + "; ";
                        }

                        row.Cells.Add(new DataGridViewTextBoxCell { Value = owner }); // Chủ sở hữu
                        row.Cells.Add(new DataGridViewTextBoxCell { Value = accessRights }); // Quyền truy cập

                        // Thêm hàng vào DataGridView
                        dataGridView1.Rows.Add(row);
                    }
                    else
                    {
                        MessageBox.Show("Không thể lấy thông tin tệp.");
                    }
                }
            }
            else
            {
                MessageBox.Show("Tệp không tồn tại.");
            }
        }

        private void btnDeleteFile_Click_1(object sender, EventArgs e)
        {
            string DfilePath = txtXoa.Text;
            if (File.Exists(DfilePath))
            {
                if (DeleteFileUsingAPI(DfilePath))
                {
                    MessageBox.Show("Xóa tệp thành công.");
                }
                else
                {
                    MessageBox.Show("Xóa tệp thất bại.");
                }
            }
            else
            {
                MessageBox.Show("Tệp không tồn tại.");
            }
        }

        private void btnCopy_Click(object sender, EventArgs e)
        {
            string sourcePath = txtSource.Text;
            string destinationPath = txtDes.Text;

            if (File.Exists(sourcePath))
            {
                if (CopyFile(sourcePath, destinationPath, false))
                {
                    MessageBox.Show("Sao chép tệp thành công.");
                }
                else
                {
                    int error = Marshal.GetLastWin32Error();
                    MessageBox.Show("Sao chép tệp thất bại, Mã lỗi: " + error);
                }
            }
            else
            {
                MessageBox.Show("Tệp nguồn không tồn tại.");
            }
        }
    }
}